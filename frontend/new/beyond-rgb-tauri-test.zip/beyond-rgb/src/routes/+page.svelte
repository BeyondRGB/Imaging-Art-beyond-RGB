<script lang="ts">
    import TextLogo from "$lib/svgs/TextLogo.svg";
    // import About from "$lib/components/About.svelte";
    import { fade } from "svelte/transition";
    import {
        CrosshairIcon,
        ApertureIcon,
        InfoIcon,
        XCircleIcon,
        CopyIcon
    } from "svelte-feather-icons";

    let showAbout = false;

    //Open a new electron window of the BeyondRGB application using IPC
    const openNewWindow = () => {
        // window.electron.openNewWindow();
    }
</script>
<!--{#if showAbout}-->
<!--    <div class="aboutContent">-->
<!--        <div class="aboutBg" on:click={() => (showAbout = false)} />-->
<!--        <div class="aboutBox">-->
<!--            <button class="closeBtn" on:click={() => (showAbout = false)}-->
<!--            ><XCircleIcon size="1.5x" /></button-->
<!--            >-->
<!--            <About />-->
<!--        </div>-->
<!--    </div>-->
<!--{/if}-->

<div class="homeContent">
    <div class="welcome">
        <h1 class="dark:text-gray-400">
            Welcome to
        </h1>
        <img src={TextLogo}  alt="app-logo" />
    </div>
    <div class="btnCol">
        <a href="/prcoess" class="homeBtn">
            <div class="btnTitle">
                <ApertureIcon size="1.25x" />
                <h2>Process</h2>
            </div>

            <span> Process a new RAW image set </span>
        </a>
        <a href="/viewer" class="homeBtn">
            <div class="btnTitle">
                <CrosshairIcon size="1.25x" />
                <h2>View</h2>
            </div>

            <span> View a previously-processed imaged set </span>
        </a>

        <!--            <button on:click={() => openNewWindow()} class="homeBtn">-->
        <!--                <div class="btnTitle">-->
        <!--                    <CopyIcon size="1.25x" />-->
        <!--                    <h2>Create Another Window</h2>-->
        <!--                </div>-->
        <!--                <span> View two reports at once </span>-->
        <!--            </button>-->

        <!--            <button on:click={() => (showAbout = true)} class="homeBtn">-->
        <!--                <div class="btnTitle">-->
        <!--                    <InfoIcon size="1.25x" />-->
        <!--                    <h2>About</h2>-->
        <!--                </div>-->
        <!--                <span> About the program </span>-->
        <!--            </button>-->
    </div>
</div>

<style lang="postcss">
    @reference "tailwindcss";

    .homeContent {
        @apply flex flex-col items-center justify-between mb-[15vh];
    }

    .homeBtn {
        @apply w-full h-full flex flex-col justify-center items-center p-[2vh] text-lg
        bg-gray-900/25 ring-0 hover:bg-gray-700 text-gray-100 hover:text-white;
    }

    .btnCol {
        @apply w-[60vw] flex flex-col justify-center items-center gap-4;
    }
    h1 {
        @apply text-4xl font-bold;
    }
    img {
        /* transform: scale(0.5); */
        pointer-events: none;
        @apply h-[10vh];
    }

    .btnTitle {
        @apply w-full flex justify-center items-center gap-1 p-1 text-xl;
    }

    .welcome {
        @apply text-black flex flex-col justify-center
        items-center gap-2 pb-[1vh];
    }

    .welcome h1 {
        @apply opacity-40;
    }
</style>